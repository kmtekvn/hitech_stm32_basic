/**
  ******************************************************************************
  * File Name          : ADC.c
  * Description        : This file provides code for the configuration
  *                      of the ADC instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "adc.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* ADC1 init function */
void MX_ADC1_Init(void)
{
  LL_ADC_InitTypeDef ADC_InitStruct = {0};
  LL_ADC_REG_InitTypeDef ADC_REG_InitStruct = {0};
  LL_ADC_CommonInitTypeDef ADC_CommonInitStruct = {0};

  /* Peripheral clock enable */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_ADC1);

  /* ADC1 DMA Init */
  
  /* ADC1 Init */
  LL_DMA_SetChannelSelection(DMA2, LL_DMA_STREAM_0, LL_DMA_CHANNEL_0);

  LL_DMA_SetDataTransferDirection(DMA2, LL_DMA_STREAM_0, LL_DMA_DIRECTION_PERIPH_TO_MEMORY);

  LL_DMA_SetStreamPriorityLevel(DMA2, LL_DMA_STREAM_0, LL_DMA_PRIORITY_MEDIUM);

  LL_DMA_SetMode(DMA2, LL_DMA_STREAM_0, LL_DMA_MODE_NORMAL);

  LL_DMA_SetPeriphIncMode(DMA2, LL_DMA_STREAM_0, LL_DMA_PERIPH_NOINCREMENT);

  LL_DMA_SetMemoryIncMode(DMA2, LL_DMA_STREAM_0, LL_DMA_MEMORY_NOINCREMENT);

  LL_DMA_SetPeriphSize(DMA2, LL_DMA_STREAM_0, LL_DMA_PDATAALIGN_HALFWORD);

  LL_DMA_SetMemorySize(DMA2, LL_DMA_STREAM_0, LL_DMA_MDATAALIGN_HALFWORD);

  LL_DMA_DisableFifoMode(DMA2, LL_DMA_STREAM_0);

  /* ADC1 interrupt Init */
  NVIC_SetPriority(ADC_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0, 0));
  NVIC_EnableIRQ(ADC_IRQn);

  /** Common config 
  */
  ADC_InitStruct.Resolution = LL_ADC_RESOLUTION_12B;
  ADC_InitStruct.DataAlignment = LL_ADC_DATA_ALIGN_RIGHT;
  ADC_InitStruct.SequencersScanMode = LL_ADC_SEQ_SCAN_DISABLE;
  LL_ADC_Init(ADC1, &ADC_InitStruct);
  ADC_REG_InitStruct.TriggerSource = LL_ADC_REG_TRIG_SOFTWARE;
  ADC_REG_InitStruct.SequencerLength = LL_ADC_REG_SEQ_SCAN_DISABLE;
  ADC_REG_InitStruct.SequencerDiscont = LL_ADC_REG_SEQ_DISCONT_DISABLE;
  ADC_REG_InitStruct.ContinuousMode = LL_ADC_REG_CONV_CONTINUOUS;
  ADC_REG_InitStruct.DMATransfer = LL_ADC_REG_DMA_TRANSFER_UNLIMITED;
  LL_ADC_REG_Init(ADC1, &ADC_REG_InitStruct);
  LL_ADC_REG_SetFlagEndOfConversion(ADC1, LL_ADC_REG_FLAG_EOC_UNITARY_CONV);
  LL_ADC_DisableIT_EOCS(ADC1);
  ADC_CommonInitStruct.CommonClock = LL_ADC_CLOCK_SYNC_PCLK_DIV2;
  ADC_CommonInitStruct.Multimode = LL_ADC_MULTI_INDEPENDENT;
  LL_ADC_CommonInit(__LL_ADC_COMMON_INSTANCE(ADC1), &ADC_CommonInitStruct);
  /** Configure Regular Channel 
  */
  LL_ADC_REG_SetSequencerRanks(ADC1, LL_ADC_REG_RANK_1, LL_ADC_CHANNEL_VREFINT);
  LL_ADC_SetChannelSamplingTime(ADC1, LL_ADC_CHANNEL_VREFINT, LL_ADC_SAMPLINGTIME_3CYCLES);
  LL_ADC_SetCommonPathInternalCh(__LL_ADC_COMMON_INSTANCE(ADC1), LL_ADC_PATH_INTERNAL_VREFINT);

}

/* USER CODE BEGIN 1 */
#define USER_ADC     ADC1
static inline  __wait_adc_stable(uint32_t count)
{
  while(count--) { asm("NOP"); };
} 

uint32_t start_conversion(void)
{
  LL_ADC_Enable(USER_ADC);
  __wait_adc_stable(10);

  LL_ADC_REG_StartConversionSWStart(USER_ADC);
  while( !LL_ADC_IsActiveFlag_EOCS(USER_ADC) ) { };
  LL_ADC_ClearFlag_EOCS(USER_ADC);
  
  return( LL_ADC_REG_ReadConversionData12(USER_ADC) & 0x0FFF); // 12-bit masked
}

void start_conversion_dma_mode(void)
{
  LL_ADC_Enable(USER_ADC);
  __wait_adc_stable(10);

  LL_ADC_REG_StartConversionSWStart(USER_ADC);
}


// Convert & return mV
#define   ADC_STEP       (733UL)  // Unsigned long - 4 bytes
#define   ADC_RATIO      (1000.0) // He so chia

uint32_t adc_convert_to_mV(uint32_t raw_data)
{
	return (uint32_t) ( ( (float)(raw_data * ADC_STEP) ) / ADC_RATIO ) ;
}


// Example DMA
void adc_dma_setup(uint16_t* user_dma_buf, uint32_t buf_size)
{
  // Config source address - Peripheral - ADC
  uint32_t adc_data_reg_addr = (uint32_t)(&(ADC1->DR));

  LL_DMA_SetPeriphAddress(DMA2, LL_DMA_STREAM_0, adc_data_reg_addr);
  // Config target address - RAM - user buffer
  LL_DMA_SetMemoryAddress(DMA2, LL_DMA_STREAM_0, (uint32_t)user_dma_buf);

  LL_DMA_SetDataLength(DMA2, LL_DMA_STREAM_0, buf_size);
}

void adc_dma_start_transaction(void)
{
  // Enable DMA request in ADC module
  LL_ADC_REG_SetDMATransfer(ADC1, LL_ADC_REG_DMA_TRANSFER_LIMITED);

  // Config DMA module
  LL_DMA_SetChannelSelection(DMA2, LL_DMA_STREAM_0, LL_DMA_CHANNEL_0);
  LL_DMA_EnableStream(DMA2, LL_DMA_STREAM_0);

}

static uint16_t _raw_dma_adc = 0;

// test function
void __adc_test_wait_dma_cplt(void)
{
  while( !LL_DMA_IsActiveFlag_TC0(DMA2) ) { };
  asm("NOP");
}

void adc_dma_unit_test(void)
{
  adc_dma_setup(&_raw_dma_adc, 1);
  adc_dma_start_transaction();

  /* start adc conversion */
  start_conversion_dma_mode();
  
  __adc_test_wait_dma_cplt();
}

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
